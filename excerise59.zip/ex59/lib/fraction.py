class Fraction:
    def __init__(self,numerator,denominator):
        self.numerator=numerator
        self.denominator=denominator
    def add(self,other):
        tukq=self.numerator*other.demoninator+other.numerator*self.denominator
        maukq=self.denominator*other.demoninator
        return Fraction(tukq,maukq)
    def minus(self,other):
        tukq = self.numerator * other.demoninator - other.numerator * self.denominator
        maukq = self.denominator * other.demoninator
        return Fraction(tukq, maukq)
    def multiply(self,other):
        tukq = self.numerator * other.numerator
        maukq = self.denominator * other.demoninator
        return Fraction(tukq, maukq)
    def divide(self,other):
        tukq = self.numerator * other.demoninator
        maukq = self.denominator * other.numerator
        return Fraction(tukq, maukq)