from PyQt6.QtWidgets import QMainWindow, QApplication

from ex59.ui.MainWIndow59Ex import MainWindow59Ex

app=QApplication([])
mywindow= MainWindow59Ex()
mywindow.setupUi(QMainWindow())
mywindow.showWindow()
app.exec()