
from ex59.lib.fraction import Fraction
from ex59.ui.MainWindow59 import Ui_MainWindow


class MainWindow59Ex(Ui_MainWindow):
    def __init__(self): #constructor: tu dong thuc thi
        pass
    def setupUi(self,MainWindow):
        super().setupUi(MainWindow)
        self.MainWindow=MainWindow
        self.setupSignalAndSlot()
    def showWindow(self):
        self.MainWindow.show()

    def setupSignalAndSlot(self):
        self.pushButtonCong.clicked.connect(self.Cong)
        self.pushButtonTru.clicked.connect(self.Tru)
        self.pushButtonNhan.clicked.connect(self.Nhan)
        self.pushButtonChia.clicked.connect(self.Chia)

    def get_fraction(self):
        try:
            tu1 = int(self.lineEditTu1.text())
            mau1 = int(self.lineEditMau1.text())
            tu2 = int(self.lineEditTu2.text())
            mau2 = int(self.lineEditMau2.text())
            if mau1 == 0 or mau2 == 0:
                self.lineEditTukq.setText("Invalid")
                self.lineEditMaukq.setText("Denominator need to be different from zero")
                return None, None
        except ValueError:
            self.lineEditTukq.setText("Invalid ")
            self.lineEditMaukq.setText("")
            return None, None
        return Fraction(tu1, mau1), Fraction(tu2, mau2)

    def Cong(self):
        ps1,ps2=self.get_fraction()
        ps3=ps1.add(ps2)
        self.lineEditTukq.setText(f"{ps3.numerator}")
        self.lineEditMaukq.setText((f"{ps3.denominator}"))
    def Tru(self):
        ps1, ps2 = self.get_fraction()
        ps3 = ps1.minus(ps2)
        self.lineEditTukq.setText(f"{ps3.numerator}")
        self.lineEditMaukq.setText((f"{ps3.denominator}"))
    def Nhan(self):
        ps1, ps2 = self.get_fraction()
        ps3 = ps1.multiply(ps2)
        self.lineEditTukq.setText(f"{ps3.numerator}")
        self.lineEditMaukq.setText((f"{ps3.denominator}"))

    def Chia(self):
        ps1, ps2 = self.get_fraction()
        if ps1 and ps2:
            if ps2.numerator == 0:
                self.lineEditTukq.setText("Invalid")
                self.lineEditMaukq.setText("Invalid")
            else:
                ps3 = ps1.divide(ps2)
                self.lineEditTukq.setText(f"{ps3.numerator}")
                self.lineEditMaukq.setText(f"{ps3.denominator}")


